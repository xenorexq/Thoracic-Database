"""
Excel export utilities using openpyxl.

These functions allow exporting either a single patient's data (across all
tables) or the entire database into an Excel workbook with multiple sheets.
The workbook will contain a sheet per table with column headers.  For a
single patient export, only the rows associated with that patient are included.

Requires openpyxl; ensure it is installed prior to packaging.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List

from openpyxl import Workbook

from db.models import Database


def _write_sheet(wb: Workbook, sheet_name: str, rows: Iterable[dict]) -> None:
    ws = wb.create_sheet(title=sheet_name)
    rows_list = list(rows)
    if not rows_list:
        return
    # Write header
    header = list(rows_list[0].keys())
    ws.append(header)
    for row in rows_list:
        ws.append([row.get(col) for col in header])


def export_patient_to_excel(db: Database, patient_id: int, file_path: Path) -> None:
    """Export data for a single patient to an Excel file."""
    wb = Workbook()
    # Remove the default sheet created by openpyxl
    wb.remove(wb.active)
    # Fetch rows per table
    tables = ["Patient", "Surgery", "Pathology", "Molecular", "FollowUp"]
    for table in tables:
        if table == "Patient":
            row = db.get_patient_by_id(patient_id)
            rows = [dict(row)] if row else []
        elif table == "FollowUp":
            row = db.get_followup(patient_id)
            rows = [dict(row)] if row else []
        else:
            # Many-to-one tables
            if table == "Surgery":
                items = db.get_surgeries_by_patient(patient_id)
            elif table == "Pathology":
                items = db.get_pathologies_by_patient(patient_id)
            elif table == "Molecular":
                items = db.get_molecular_by_patient(patient_id)
            else:
                items = []
            rows = [dict(row) for row in items]
        _write_sheet(wb, table, rows)
    wb.save(file_path)


def export_all_to_excel(db: Database, file_path: Path) -> None:
    """Export entire database to an Excel file (one sheet per table)."""
    wb = Workbook()
    # Remove default sheet
    wb.remove(wb.active)
    # For each table, fetch all rows
    for table in ["Patient", "Surgery", "Pathology", "Molecular", "FollowUp"]:
        rows = db.export_table(table)
        rows_dicts = [dict(row) for row in rows]
        _write_sheet(wb, table, rows_dicts)
    wb.save(file_path)
