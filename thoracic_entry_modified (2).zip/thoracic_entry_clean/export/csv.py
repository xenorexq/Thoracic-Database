"""
CSV export utilities for thoracic entry application.

These functions write one CSV file per table.  For a single patient export,
files are named with a prefix (e.g. ``patient123_Patient.csv``).  For full
database export, file names are simply ``Patient.csv`` etc.

Column headers are written as the first row.  Values are written as strings.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable, List

from db.models import Database


def _write_csv(path: Path, rows: Iterable[dict]) -> None:
    rows_list = list(rows)
    with path.open("w", newline="", encoding="utf-8") as f:
        if not rows_list:
            return
        writer = csv.DictWriter(f, fieldnames=rows_list[0].keys())
        writer.writeheader()
        for row in rows_list:
            writer.writerow(row)


def export_patient_to_csv(db: Database, patient_id: int, dir_path: Path) -> List[Path]:
    """Export a single patient to CSV files.

    Returns list of file paths created.
    """
    files: List[Path] = []
    # Create directory if not exists
    dir_path.mkdir(parents=True, exist_ok=True)
    # Determine prefix for file names
    prefix = f"patient{patient_id}"
    # Prepare per-table rows
    tables = ["Patient", "Surgery", "Pathology", "Molecular", "FollowUp"]
    for table in tables:
        if table == "Patient":
            row = db.get_patient_by_id(patient_id)
            rows = [dict(row)] if row else []
        elif table == "FollowUp":
            row = db.get_followup(patient_id)
            rows = [dict(row)] if row else []
        else:
            if table == "Surgery":
                items = db.get_surgeries_by_patient(patient_id)
            elif table == "Pathology":
                items = db.get_pathologies_by_patient(patient_id)
            elif table == "Molecular":
                items = db.get_molecular_by_patient(patient_id)
            else:
                items = []
            rows = [dict(row) for row in items]
        file_path = dir_path / f"{prefix}_{table}.csv"
        _write_csv(file_path, rows)
        files.append(file_path)
    return files


def export_all_to_csv(db: Database, dir_path: Path) -> List[Path]:
    """Export entire database to CSV files.

    Returns list of file paths created.
    """
    files: List[Path] = []
    dir_path.mkdir(parents=True, exist_ok=True)
    for table in ["Patient", "Surgery", "Pathology", "Molecular", "FollowUp"]:
        rows = db.export_table(table)
        rows_dicts = [dict(row) for row in rows]
        file_path = dir_path / f"{table}.csv"
        _write_csv(file_path, rows_dicts)
        files.append(file_path)
    return files
