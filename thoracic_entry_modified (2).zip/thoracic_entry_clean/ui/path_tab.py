"""
Pathology tab for thoracic entry application.

Provides a list and form for entering pathology reports for a patient.  Users
can create, edit, and delete multiple pathology records.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional

from db.models import Database


class PathologyTab(ttk.Frame):
    def __init__(self, parent: tk.Widget, app: "ThoracicApp") -> None:
        super().__init__(parent)
        self.app = app
        self.db: Database = app.db
        self.current_path_id: Optional[int] = None
        self._build_widgets()

    def _build_widgets(self) -> None:
        # 病理列表
        list_frame = ttk.LabelFrame(self, text="病理列表")
        list_frame.pack(fill="both", expand=True, padx=5, pady=5)
        columns = ["path_id", "pathology_no", "histology", "p_stage"]
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("path_id", text="ID")
        self.tree.heading("pathology_no", text="病理号")
        self.tree.heading("histology", text="组织学")
        self.tree.heading("p_stage", text="分期")
        self.tree.column("path_id", width=50)
        self.tree.column("pathology_no", width=150)
        self.tree.column("histology", width=150)
        self.tree.column("p_stage", width=100)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # 使用滚动框架
        canvas = tk.Canvas(self)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # === 基本信息 ===
        basic_frame = ttk.LabelFrame(scrollable_frame, text="基本信息")
        basic_frame.pack(fill="x", padx=10, pady=5)

        row = 0
        # 病理号
        ttk.Label(basic_frame, text="病理号:").grid(row=row, column=0, sticky="e", padx=5, pady=3)
        self.pathology_no_var = tk.StringVar()
        ttk.Entry(basic_frame, textvariable=self.pathology_no_var, width=20).grid(row=row, column=1, sticky="w", padx=5)

        # 标本类型（下拉）
        ttk.Label(basic_frame, text="标本类型:").grid(row=row, column=2, sticky="e", padx=5)
        self.specimen_var = tk.StringVar()
        ttk.Combobox(
            basic_frame,
            textvariable=self.specimen_var,
            values=["手术切除", "活检", "穿刺", "其他"],
            state="readonly",
            width=12
        ).grid(row=row, column=3, sticky="w", padx=5)

        # === 肺癌病理 ===
        self.lung_path_frame = ttk.LabelFrame(scrollable_frame, text="肺癌病理")
        self.lung_path_frame.pack(fill="x", padx=10, pady=5)

        lung_row = 0
        # 组织学（肺癌）
        ttk.Label(self.lung_path_frame, text="组织学:").grid(row=lung_row, column=0, sticky="e", padx=5, pady=3)
        self.lung_hist_var = tk.StringVar()
        self.lung_hist_cb = ttk.Combobox(
            self.lung_path_frame,
            textvariable=self.lung_hist_var,
            values=["腺癌", "鳞癌", "小细胞癌", "大细胞癌", "腺鳞癌", "类癌", "其他"],
            width=12
        )
        self.lung_hist_cb.grid(row=lung_row, column=1, sticky="w", padx=5)

        # 分化（肺癌）
        ttk.Label(self.lung_path_frame, text="分化:").grid(row=lung_row, column=2, sticky="e", padx=5)
        self.lung_diff_var = tk.StringVar()
        ttk.Combobox(
            self.lung_path_frame,
            textvariable=self.lung_diff_var,
            values=["高分化", "中分化", "低分化", "未分化"],
            state="readonly",
            width=10
        ).grid(row=lung_row, column=3, sticky="w", padx=5)

        lung_row += 1
        # pTNM（肺癌）
        ttk.Label(self.lung_path_frame, text="pT:").grid(row=lung_row, column=0, sticky="e", padx=5, pady=3)
        self.lung_pt_var = tk.StringVar()
        ttk.Combobox(
            self.lung_path_frame,
            textvariable=self.lung_pt_var,
            values=["pT0", "pTis", "pT1", "pT1a", "pT1b", "pT1c", "pT2", "pT2a", "pT2b", "pT3", "pT4"],
            width=8
        ).grid(row=lung_row, column=1, sticky="w", padx=5)

        ttk.Label(self.lung_path_frame, text="pN:").grid(row=lung_row, column=2, sticky="e", padx=5)
        self.lung_pn_var = tk.StringVar()
        ttk.Combobox(
            self.lung_path_frame,
            textvariable=self.lung_pn_var,
            values=["pN0", "pN1", "pN2", "pN3"],
            width=8
        ).grid(row=lung_row, column=3, sticky="w", padx=5)

        ttk.Label(self.lung_path_frame, text="pM:").grid(row=lung_row, column=4, sticky="e", padx=5)
        self.lung_pm_var = tk.StringVar()
        ttk.Combobox(
            self.lung_path_frame,
            textvariable=self.lung_pm_var,
            values=["pM0", "pM1", "pM1a", "pM1b", "pM1c"],
            width=8
        ).grid(row=lung_row, column=5, sticky="w", padx=5)

        ttk.Label(self.lung_path_frame, text="分期:").grid(row=lung_row, column=6, sticky="e", padx=5)
        self.lung_p_stage_var = tk.StringVar()
        ttk.Entry(self.lung_path_frame, textvariable=self.lung_p_stage_var, width=10).grid(row=lung_row, column=7, sticky="w", padx=5)

        # === 食管癌病理 ===
        self.eso_path_frame = ttk.LabelFrame(scrollable_frame, text="食管癌病理")
        self.eso_path_frame.pack(fill="x", padx=10, pady=5)

        eso_row = 0
        # 组织学（食管癌）
        ttk.Label(self.eso_path_frame, text="组织学:").grid(row=eso_row, column=0, sticky="e", padx=5, pady=3)
        self.eso_hist_var = tk.StringVar()
        ttk.Combobox(
            self.eso_path_frame,
            textvariable=self.eso_hist_var,
            values=["SCC", "AD", "其他"],
            width=12
        ).grid(row=eso_row, column=1, sticky="w", padx=5)

        # 分化（食管癌）
        ttk.Label(self.eso_path_frame, text="分化:").grid(row=eso_row, column=2, sticky="e", padx=5)
        self.eso_diff_var = tk.StringVar()
        ttk.Combobox(
            self.eso_path_frame,
            textvariable=self.eso_diff_var,
            values=["高分化", "中分化", "低分化", "未分化"],
            state="readonly",
            width=10
        ).grid(row=eso_row, column=3, sticky="w", padx=5)

        eso_row += 1
        # pTNM（食管癌）
        ttk.Label(self.eso_path_frame, text="pT:").grid(row=eso_row, column=0, sticky="e", padx=5, pady=3)
        self.eso_pt_var = tk.StringVar()
        ttk.Combobox(
            self.eso_path_frame,
            textvariable=self.eso_pt_var,
            values=["pT0", "pTis", "pT1", "pT1a", "pT1b", "pT2", "pT3", "pT4", "pT4a", "pT4b"],
            width=8
        ).grid(row=eso_row, column=1, sticky="w", padx=5)

        ttk.Label(self.eso_path_frame, text="pN:").grid(row=eso_row, column=2, sticky="e", padx=5)
        self.eso_pn_var = tk.StringVar()
        ttk.Combobox(
            self.eso_path_frame,
            textvariable=self.eso_pn_var,
            values=["pN0", "pN1", "pN2", "pN3"],
            width=8
        ).grid(row=eso_row, column=3, sticky="w", padx=5)

        ttk.Label(self.eso_path_frame, text="pM:").grid(row=eso_row, column=4, sticky="e", padx=5)
        self.eso_pm_var = tk.StringVar()
        ttk.Combobox(
            self.eso_path_frame,
            textvariable=self.eso_pm_var,
            values=["pM0", "pM1"],
            width=8
        ).grid(row=eso_row, column=5, sticky="w", padx=5)

        ttk.Label(self.eso_path_frame, text="分期:").grid(row=eso_row, column=6, sticky="e", padx=5)
        self.eso_p_stage_var = tk.StringVar()
        ttk.Entry(self.eso_path_frame, textvariable=self.eso_p_stage_var, width=10).grid(row=eso_row, column=7, sticky="w", padx=5)

        # === 病理特征（复选框） ===
        features_frame = ttk.LabelFrame(scrollable_frame, text="病理特征")
        features_frame.pack(fill="x", padx=10, pady=5)

        feat_row = 0
        self.lvi_var = tk.IntVar()
        ttk.Checkbutton(features_frame, text="脉管内癌栓", variable=self.lvi_var).grid(row=feat_row, column=0, sticky="w", padx=10, pady=3)

        self.airway_spread_var = tk.IntVar()
        ttk.Checkbutton(features_frame, text="沿气道传播", variable=self.airway_spread_var).grid(row=feat_row, column=1, sticky="w", padx=10)

        self.pni_var = tk.IntVar()
        ttk.Checkbutton(features_frame, text="周围神经侵犯", variable=self.pni_var).grid(row=feat_row, column=2, sticky="w", padx=10)

        self.pl_inv_var = tk.IntVar()
        ttk.Checkbutton(features_frame, text="胸膜侵犯", variable=self.pl_inv_var).grid(row=feat_row, column=3, sticky="w", padx=10)

        # === 淋巴结和TRG ===
        ln_frame = ttk.LabelFrame(scrollable_frame, text="淋巴结和治疗反应")
        ln_frame.pack(fill="x", padx=10, pady=5)

        ln_row = 0
        ttk.Label(ln_frame, text="淋巴结总数:").grid(row=ln_row, column=0, sticky="e", padx=5, pady=3)
        self.ln_total_var = tk.StringVar()
        ttk.Entry(ln_frame, textvariable=self.ln_total_var, width=8).grid(row=ln_row, column=1, sticky="w", padx=5)

        ttk.Label(ln_frame, text="阳性数:").grid(row=ln_row, column=2, sticky="e", padx=5)
        self.ln_pos_var = tk.StringVar()
        ttk.Entry(ln_frame, textvariable=self.ln_pos_var, width=8).grid(row=ln_row, column=3, sticky="w", padx=5)

        ttk.Label(ln_frame, text="TRG:").grid(row=ln_row, column=4, sticky="e", padx=5)
        self.trg_var = tk.StringVar()
        ttk.Entry(ln_frame, textvariable=self.trg_var, width=8).grid(row=ln_row, column=5, sticky="w", padx=5)

        # === 备注 ===
        notes_frame = ttk.LabelFrame(scrollable_frame, text="备注")
        notes_frame.pack(fill="x", padx=10, pady=5)
        self.notes_text = tk.Text(notes_frame, width=80, height=3)
        self.notes_text.pack(fill="x", padx=5, pady=5)

        # === 按钮 ===
        btn_frame = ttk.Frame(scrollable_frame)
        btn_frame.pack(fill="x", padx=10, pady=5)
        ttk.Button(btn_frame, text="新建", command=self.new_record).pack(side="left", padx=2)
        ttk.Button(btn_frame, text="保存", command=self.save_record).pack(side="left", padx=2)
        ttk.Button(btn_frame, text="删除", command=self.delete_record).pack(side="left", padx=2)

    def load_patient(self, patient_id: Optional[int]) -> None:
        self.current_path_id = None
        for item in self.tree.get_children():
            self.tree.delete(item)
        if not patient_id:
            return
        
        # 根据癌种显示/隐藏对应的病理框架
        if hasattr(self.app, 'current_cancer_type'):
            cancer_type = self.app.current_cancer_type
            if cancer_type == "肺癌":
                self.lung_path_frame.pack(fill="x", padx=10, pady=5, after=self.lung_path_frame.master.winfo_children()[1])
                self.eso_path_frame.pack_forget()
            elif cancer_type == "食管癌":
                self.eso_path_frame.pack(fill="x", padx=10, pady=5, after=self.eso_path_frame.master.winfo_children()[1])
                self.lung_path_frame.pack_forget()
            else:
                self.lung_path_frame.pack(fill="x", padx=10, pady=5, after=self.lung_path_frame.master.winfo_children()[1])
                self.eso_path_frame.pack(fill="x", padx=10, pady=5, after=self.lung_path_frame)
        
        pathologies = self.db.get_pathologies_by_patient(patient_id)
        for p in pathologies:
            self.tree.insert("", tk.END, iid=p["path_id"], 
                           values=(p["path_id"], p.get("pathology_no"), p.get("histology"), p.get("p_stage")))

    def _on_tree_select(self, event) -> None:
        sel = self.tree.selection()
        if sel:
            self.load_record(int(sel[0]))

    def load_record(self, path_id: int) -> None:
        row = self.db.conn.execute("SELECT * FROM Pathology WHERE path_id=?", (path_id,)).fetchone()
        if not row:
            return
        row = dict(row)
        self.current_path_id = path_id
        
        # 基本信息
        self.pathology_no_var.set(row.get("pathology_no") or "")
        self.specimen_var.set(row.get("specimen_type") or "")
        
        # 判断是肺癌还是食管癌（根据histology字段）
        histology = row.get("histology") or ""
        
        # 肺癌病理
        if histology in ["腺癌", "鳞癌", "小细胞癌", "大细胞癌", "腺鳞癌", "类癌"]:
            self.lung_hist_var.set(histology)
            self.lung_diff_var.set(row.get("differentiation") or "")
            self.lung_pt_var.set(row.get("pt") or "")
            self.lung_pn_var.set(row.get("pn") or "")
            self.lung_pm_var.set(row.get("pm") or "")
            self.lung_p_stage_var.set(row.get("p_stage") or "")
        else:
            # 食管癌病理
            self.eso_hist_var.set(histology)
            self.eso_diff_var.set(row.get("differentiation") or "")
            self.eso_pt_var.set(row.get("pt") or "")
            self.eso_pn_var.set(row.get("pn") or "")
            self.eso_pm_var.set(row.get("pm") or "")
            self.eso_p_stage_var.set(row.get("p_stage") or "")
        
        # 病理特征
        self.lvi_var.set(row.get("lvi") or 0)
        self.airway_spread_var.set(row.get("airway_spread") or 0)
        self.pni_var.set(row.get("pni") or 0)
        self.pl_inv_var.set(row.get("pleural_invasion") or 0)
        
        # 淋巴结和TRG
        self.ln_total_var.set(str(row.get("ln_total") or ""))
        self.ln_pos_var.set(str(row.get("ln_positive") or ""))
        self.trg_var.set(str(row.get("trg") or ""))
        
        # 备注
        self.notes_text.delete("1.0", tk.END)
        self.notes_text.insert(tk.END, row.get("notes_path") or "")

    def new_record(self) -> None:
        self.current_path_id = None
        self.pathology_no_var.set("")
        self.specimen_var.set("")
        self.lung_hist_var.set("")
        self.lung_diff_var.set("")
        self.lung_pt_var.set("")
        self.lung_pn_var.set("")
        self.lung_pm_var.set("")
        self.lung_p_stage_var.set("")
        self.eso_hist_var.set("")
        self.eso_diff_var.set("")
        self.eso_pt_var.set("")
        self.eso_pn_var.set("")
        self.eso_pm_var.set("")
        self.eso_p_stage_var.set("")
        self.lvi_var.set(0)
        self.airway_spread_var.set(0)
        self.pni_var.set(0)
        self.pl_inv_var.set(0)
        self.ln_total_var.set("")
        self.ln_pos_var.set("")
        self.trg_var.set("")
        self.notes_text.delete("1.0", tk.END)

    def save_record(self) -> None:
        if not self.app.current_patient_id:
            messagebox.showerror("错误", "请先选择或保存患者")
            return
        
        # 判断是肺癌还是食管癌
        lung_hist = self.lung_hist_var.get().strip()
        eso_hist = self.eso_hist_var.get().strip()
        
        if lung_hist:
            histology = lung_hist
            differentiation = self.lung_diff_var.get() or None
            pt = self.lung_pt_var.get() or None
            pn = self.lung_pn_var.get() or None
            pm = self.lung_pm_var.get() or None
            p_stage = self.lung_p_stage_var.get() or None
        elif eso_hist:
            histology = eso_hist
            differentiation = self.eso_diff_var.get() or None
            pt = self.eso_pt_var.get() or None
            pn = self.eso_pn_var.get() or None
            pm = self.eso_pm_var.get() or None
            p_stage = self.eso_p_stage_var.get() or None
        else:
            messagebox.showerror("错误", "请填写组织学类型")
            return
        
        data = {
            "pathology_no": self.pathology_no_var.get() or None,
            "specimen_type": self.specimen_var.get() or None,
            "histology": histology,
            "differentiation": differentiation,
            "pt": pt,
            "pn": pn,
            "pm": pm,
            "p_stage": p_stage,
            "lvi": self.lvi_var.get(),
            "airway_spread": self.airway_spread_var.get(),
            "pni": self.pni_var.get(),
            "pleural_invasion": self.pl_inv_var.get(),
            "ln_total": int(self.ln_total_var.get()) if self.ln_total_var.get() else None,
            "ln_positive": int(self.ln_pos_var.get()) if self.ln_pos_var.get() else None,
            "trg": int(self.trg_var.get()) if self.trg_var.get() else None,
            "notes_path": self.notes_text.get("1.0", tk.END).strip() or None,
        }
        try:
            if self.current_path_id is None:
                new_id = self.db.insert_pathology(self.app.current_patient_id, data)
                messagebox.showinfo("成功", f"病理记录已添加(ID={new_id})")
            else:
                self.db.update_pathology(self.current_path_id, data)
                messagebox.showinfo("成功", "病理记录已更新")
            self.load_patient(self.app.current_patient_id)
        except Exception as e:
            messagebox.showerror("错误", str(e))

    def delete_record(self) -> None:
        if not self.current_path_id:
            return
        if not messagebox.askyesno("确定", "确定删除当前病理记录?"):
            return
        try:
            self.db.delete_pathology(self.current_path_id)
            messagebox.showinfo("成功", "病理记录已删除")
            self.current_path_id = None
            self.load_patient(self.app.current_patient_id)
            self.new_record()
        except Exception as e:
            messagebox.showerror("错误", str(e))

